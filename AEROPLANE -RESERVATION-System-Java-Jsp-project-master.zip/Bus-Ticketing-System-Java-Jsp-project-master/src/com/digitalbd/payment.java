package com.digitalbd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class payment
 */
@WebServlet("/payment")
public class payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String code=request.getParameter("code11");
		   String name = request.getParameter("fullname");
		   String rr=request.getParameter("userId");
		   String email=request.getParameter("email");
		   String phone=request.getParameter("phone");
		   String cardNumber = request.getParameter("cardnumber");
		   String expiryDate = request.getParameter("expmonth");
		   String expiryYear= request.getParameter("expyear");
		   String cvv = request.getParameter("cvv");
		   System.out.println(code+" "+email+" "+phone+" "+cardNumber+" "+expiryDate+" "+expiryYear+" "+cvv);
		   PrintWriter out=response.getWriter();
		   // Validate the payment details
		   if(name == null || cardNumber == null || expiryDate == null || cvv == null)
		{
		      out.println("Please enter all the payment details.");
		   } else {
		      // Store the payment details in the database
		      try {
		         Class.forName("com.mysql.jdbc.Driver");
		         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ticketing_system", "root", "");
		         PreparedStatement ps = con.prepareStatement("INSERT INTO payments(name,email, phoneno,card_number, expiry_date, expiry_year,cvv,BusNo) VALUES(?,?, ?, ?, ?, ?, ?, ?)");
		         ps.setString(1, name);
		         ps.setString(2,email);
		         ps.setString(3, phone);
		         ps.setString(4, cardNumber);
		         ps.setString(5, expiryDate);
		         ps.setString(6, expiryYear);
		         ps.setString(7, cvv);
		         ps.setString(8, code);
		         int rows = ps.executeUpdate();
		         if(rows > 0) {
		            out.println("Payment successful.");
		         } else {
		            out.println("Payment failed.");
		         }
		      } catch(Exception e) {
		         out.println("Error: " + e.getMessage());
		      }
		   }
	}

}
