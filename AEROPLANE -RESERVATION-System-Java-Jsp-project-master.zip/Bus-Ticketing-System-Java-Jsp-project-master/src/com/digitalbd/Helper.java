package com.digitalbd;

import java.util.HashMap;

public class Helper {
	public static String baseUrl = "http://localhost:8090/Train_Ticket_System/";
	public static String TestName="T ruon";
	public static String Currency = "RS";
	public static HashMap<String,String> TrainsCoach(){
		HashMap<String,String> coach = new HashMap<String,String>();
		coach.put("AC-CLASS WITH WIFI", "AC-CLASS WITH WIFI");
		coach.put("NON-AC", "NON AC ");
		coach.put("AC-CLASS", "AC CLASS");
		coach.put("NON_AC WITH DVD", "NON AC WITH DVD");
		return coach;
	}
}
