package AllLayout;

public class Train {
	public String name,id,code,type;
	public int totalSeat = 0;
}
