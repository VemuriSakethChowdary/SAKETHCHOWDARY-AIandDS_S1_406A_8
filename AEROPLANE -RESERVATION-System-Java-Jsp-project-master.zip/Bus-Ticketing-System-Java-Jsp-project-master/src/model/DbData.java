package model;

public class DbData {
	public String name;
	public String email;
	public String phoneno;
public String BusNo;
public DbData(String a,String b,String c,String d)
{
	name=a;
	email=b;
	phoneno=c;
	BusNo=d;
}
public String getName()
{
	return name;
}
public String getEmail()
{
	return email;
}
public String getphoneNo()
{
	return phoneno;
}
public String getBusNo()
{
	return BusNo;
}
}
